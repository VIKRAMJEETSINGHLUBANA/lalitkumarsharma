<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'JtkZaL5XTfMHGRNI3evWnmUWIbOBqJJCE7KeiYR2tv4j/Sa7IUlm/vLsvZcAMGZF2GTAKwoL9mBkoEdsJWGIuw==');
define('SECURE_AUTH_KEY',  '//KxKvSKKPwePEJThX184uofYzz0oHTquQUbjtFwZ0rvcuaB5bpkXK6Q2xZQkvGb+sk1HpOQM67JXxRH8VP0Iw==');
define('LOGGED_IN_KEY',    'ch5HJWoR745m4KZrwOOM+8QEgnlThbt2jKPuBQAri6XT5b7/c4clgrEeRjFM3G85pvtxmDTMvJQ8z16Kx3myxg==');
define('NONCE_KEY',        'FQozUvhZghgwmTBNqYt3WlQII3l2OYXkW+tkn3ax2JfK3ZP1Pb0RIjlwu1V/wy4Uzb5yhONgRzo7//dAuzPbzQ==');
define('AUTH_SALT',        'Z/mj9z9AXZXjixV1+27FacBD6JBwVEux6xFNA6RoE+xQwk/Q7ZiXVrv/iAZWHFZX+Iaus8fX2RQo3pzLO8i4BQ==');
define('SECURE_AUTH_SALT', 'SMh8sS08ZTrsbqCH7tJSTdGANSPTIwNbaTs5ZYtSHE+QXzkcsiyuZJ9bAFfFfMhsfhFJ/Erq8cOUDCCKzvZyVg==');
define('LOGGED_IN_SALT',   'PahzhFSmeAdX/wV0k4xjg0ToXUNDxzKgVIyAiTe3+J2M1bVaS79mys9Go7kqOOACxPwEQGuRqznaGqHWhaNOxg==');
define('NONCE_SALT',       'fAAipGvHiC8DXVyUOegcZTROfv1fVCC4N34JD7yQpcz0CpcG6eP2J2HTkl0THQfSRB0FtB21EYlHo2WAlN8Vxg==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
